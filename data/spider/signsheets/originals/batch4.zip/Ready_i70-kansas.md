# Sign sheet — I-70 / Kansas high plains (EDITABLE, draft)

Corridor #7. Draft for review -- rename to `ready_i70-kansas.md` when approved.
Facts from public data; copy invented. One built leg:
`kansas_city_mo_us -> denver_co_us` (603 mi). **at_mi are ESTIMATES.**

---

<!-- complete-legs -->
**Complete built legs in this corridor (use ONLY these slugs for `leg:`):**
`kansas_city_mo_us -> denver_co_us` (603)

### Oz Museum
- treatment: billboard
- leg: kansas_city_mo_us -> denver_co_us
- at_mi: 90
- spoken: Billboard: The Oz Museum ahead in Wamego. Follow the yellow brick road off Interstate seventy. There's no place like home.
- describe: Ruby slippers, flying monkeys, and more Dorothy than one small town should legally hold -- the Oz Museum in Wamego packs generations of Wizard of Oz collecting into one very committed building.

### Mushroom Rock
- treatment: landmark
- leg: kansas_city_mo_us -> denver_co_us
- at_mi: 200
- spoken: Off Interstate seventy ahead stand the Mushroom Rocks, giant sandstone toadstools balanced on the prairie, carved by wind and time -- once trail markers for wagons on the old Smoky Hill route.

### World's Largest Czech Egg
- treatment: billboard
- leg: kansas_city_mo_us -> denver_co_us
- at_mi: 225
- spoken: Billboard: The world's largest Czech egg ahead in Wilson, the Czech Capital of Kansas. Twenty feet of hand-painted folk art, because every small town deserves one enormous thing.

### The Garden of Eden
- treatment: billboard
- leg: kansas_city_mo_us -> denver_co_us
- at_mi: 235
- spoken: Billboard: The Garden of Eden ahead in Lucas -- concrete Bible scenes and populist politics in a front yard, roadside folk art like nowhere else.
- describe: Built over decades by one very determined old man, the Garden of Eden in Lucas is a yard packed with hand-poured concrete tableaux -- Adam and Eve, the working man against the powerful, and, they say, the builder himself still on display.

### World's Largest Prairie Dog
- treatment: billboard
- leg: kansas_city_mo_us -> denver_co_us
- at_mi: 330
- spoken: Billboard: See the world's largest prairie dog ahead near Oakley -- eight thousand pounds of concrete rodent, plus live rattlesnakes and a genuine five-legged cow. Roadside science at its very finest.
- describe: Prairie Dog Town, off Interstate seventy near Oakley, delivers exactly what the signs promise -- a giant concrete prairie dog, a town of live ones, rattlesnakes, and a real five-legged cow, a High Plains institution since the fifties.

### Giant Buffalo Bill
- treatment: billboard
- leg: kansas_city_mo_us -> denver_co_us
- at_mi: 350
- spoken: Billboard: A giant Buffalo Bill on horseback ahead near Oakley, forever charging a bronze buffalo. Bigger than life, and life on the plains was already pretty big. Please stop for real buffalos.

### Monument Rocks
- treatment: landmark
- leg: kansas_city_mo_us -> denver_co_us
- at_mi: 368
- spoken: South of Interstate seventy near Oakley stand Monument Rocks, chalk spires and arches left by an ancient inland sea, or was it really a sea  -- the first national natural landmark, standing alone on the high plains.

---

## Held / notes
- Oakley trio now spread (three-thirty / three-fifty / three-sixty-eight). No
  worries on the manual spread -- the runtime min is only two miles, so they were
  fine; spreading just improves pacing.
- Added this pass: Mushroom Rock, the world's largest Czech egg (Wilson), and the
  Garden of Eden (Lucas).
## Sources
I-70 Kansas roadside records (Oz Museum / Prairie Dog Town / Buffalo Bill statue /
Monument Rocks). Facts only; sign copy invented.
